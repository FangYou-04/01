#include "Congfig.hpp"
#include "Struct.hpp"
#include "PoseSlove.hpp"
#include <algorithm>
#include <cmath>
#include <cfloat>


// 图像预处理
cv::Mat ArmorsDetector::preprocessImage(const cv::Mat &img) 
{
    
    if(img.empty() || img.data == nullptr || img.rows == 0 ||
         img.cols == 0 || img.type() != CV_8UC3)
    {
        std::cout << "[ERROR]预处理图像无效" << std::endl;
        return cv::Mat();
    }

    cv::Mat img_continuous = img.isContinuous() ? img : img.clone();

    // 亮度调整（用户可能设置 beta 为负值，例如 -50）
    cv::Mat img_L;
    int beta = -90; // 如果要测试不同亮度请修改此处
    img_continuous.convertTo(img_L, -1, 1, beta);

   cv::Mat gray, blur, binary;
    cv::cvtColor(img_L, gray, cv::COLOR_BGR2GRAY);
    cv::GaussianBlur(gray, blur, cv::Size(5, 5), 0); // 在灰度图阶段模糊，减少噪声
    cv::threshold(blur, binary, 0, 255, cv::THRESH_BINARY | cv::THRESH_OTSU);

    cv::Mat kernel = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(config_.morph_config.kernel_size, config_.morph_config.kernel_size));
    cv::Mat img_N;
    cv::morphologyEx(binary, img_N, cv::MORPH_OPEN, kernel); // 直接对二值图形态学操作
    cv::imshow("二值化", img_N);

    return img_N;
}

// 调整旋转矩形角度，使其长边接近垂直方向
void adjustRotatedRect(cv::RotatedRect& rect, const float angle_to_up)
{
    // 保证 rect.size.height 为长边，并对 angle 做规范化到 [-90,90)
    float w = rect.size.width;
    float h = rect.size.height;
    if (w > h) {
        std::swap(rect.size.width, rect.size.height);
        rect.angle += 90.0f; // 旋转角度随长短边交换而变化
    }
    // 规范化角度到 [-90,90)
    while (rect.angle >= 90.0f) rect.angle -= 180.0f;
    while (rect.angle < -90.0f) rect.angle += 180.0f;
}

// 灯条检测
std::vector<Light> ArmorsDetector::detectLights(const cv::Mat &mask) 
{
    // 寻找轮廓
    std::vector<std::vector<cv::Point>> contours;
    std::vector<cv::Vec4i> hierarchy;
    cv::findContours(mask, contours, hierarchy, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

    // 筛选灯条
    std::vector<Light> lights;
    for (size_t i = 0; i < contours.size(); i++) 
    {
        // if (contours[i].size() < 5) continue; // 拟合椭圆至少需要5个点

        double area = cv::contourArea(contours[i]);
        if (area < config_.light_config.area) continue;

        // 获取最小外接矩形
        cv::RotatedRect rect = cv::minAreaRect(contours[i]);

        // cv::RotatedRect rect;
        // try 
        // {
        //     rect = cv::fitEllipse(contours[i]);
        // } 
        // catch (...) 
        // {
        //     rect = cv::minAreaRect(contours[i]); // 椭圆拟合失败时降级
        // }

        adjustRotatedRect(rect, config_.light_config.angle_to_up); // 调整角度使其接近垂直

        // 规范化宽高
        float width = rect.size.width;
        float height = rect.size.height;
        if (width > height) cv::swap(width, height);

        // 计算比例和角度
        float ratio = 0.0f; // 【必做】变量显式初始化
        const float eps = 1e-6; // 浮点精度容错值，避免除0
        if (width > eps) {
            ratio = height / width;
        }

        float angle = rect.angle;

        // // 计算轮廓的圆形度（灯条为细长矩形，圆形度接近0；反光点为圆形，圆形度接近1）
        // float perimeter = cv::arcLength(contours[i], true);
        // float circularity = 0.0f; // 【必做】变量显式初始化
        // if (perimeter > eps) {
        //     circularity = (4 * CV_PI * area) / (perimeter * perimeter);
        // }
        
        // bool isNoise = (circularity > 0.8f) && (ratio < 1.8f); // 根据经验值判断是否为噪声
        // if (isNoise) continue;

        // 筛选符合比例和角度要求的灯条
        if (ratio > config_.light_config.ratio_max || ratio < config_.light_config.ratio_min)
            continue;

        if (std::fabs(angle) > config_.light_config.angle)
            continue;

        Light light;
        light.rect = rect;
        light.rat = ratio;
        light.AbsAngle = angle;
        light.center = rect.center;

        cv::Point2f pts[4];
        light.rect.points(pts);

        const int vertexCount = sizeof(light.vertices)/sizeof(light.vertices[0]);
        
        for (int k = 0; k < 4; k++) 
        {
            light.vertices[k] = pts[k];
        }
        lights.push_back(light);
        
    }
    // 调试：打印检测到的灯条数量
    std::cout << "检测到灯条数量：" << lights.size() << std::endl;

    return lights;
}

// 装甲板配对
std::vector<Armors> ArmorsDetector::matchArmors(const std::vector<Light> &lights) 
{
    std::vector<Armors> armors;
    if (lights.size() < 2) return armors;

    // 两两配对灯条
    for (size_t i = 0; i < lights.size(); i++) 
    {
        for (size_t j = i + 1; j < lights.size(); j++) 
        {
            const Light &bar1 = lights[i];
            const Light &bar2 = lights[j];

            const Light &leftBar = bar1.center.x < bar2.center.x ? bar1 : bar2;
            const Light &rightBar = bar1.center.x < bar2.center.x ? bar2 : bar1;

            float distance = cv::norm(leftBar.center - rightBar.center);
            float heightAvg = (leftBar.rect.size.height + rightBar.rect.size.height) / 2;

            const float eps = 1e-6; // 浮点精度容错值，避免除0
            if (heightAvg < eps) continue; // 避免除0

            // 恢复垂直偏差筛选（关键！）
            float yDiff = std::fabs(leftBar.center.y - rightBar.center.y);
            if (yDiff > heightAvg * 0.9f) continue; // 垂直偏差≤50%

            // 距离筛选
            if (distance < heightAvg * config_.armor_config.distance_min || distance > heightAvg * config_.armor_config.distance_max) 
                continue; 

            float angle = fabs(atan2(rightBar.center.y - leftBar.center.y,
                                     rightBar.center.x - leftBar.center.x) * 180 / CV_PI);
            if (angle > config_.armor_config.armor_angle) continue;

            float heightDiff = fabs(leftBar.rect.size.height - rightBar.rect.size.height)
                               / std::max(leftBar.rect.size.height, rightBar.rect.size.height);
            if (heightDiff > config_.armor_config.height_diff) continue;

            float angleDiff = fabs(leftBar.AbsAngle - rightBar.AbsAngle);
            if (angleDiff > config_.armor_config.angle_diff) continue;

            float armorRatio = distance / heightAvg;
            if (armorRatio < config_.armor_config.armor_ratio_min || armorRatio > config_.armor_config.armor_ratio_max) continue;

            Armors armor;
            armor.left = leftBar;
            armor.right = rightBar;
            armor.center = (leftBar.center + rightBar.center) * 0.5f;

            cv::Point2f armorPts[4];
            armorPts[0] = leftBar.vertices[1].y > leftBar.vertices[3].y ? leftBar.vertices[1] : leftBar.vertices[3];
            armorPts[1] = rightBar.vertices[0].y > rightBar.vertices[2].y ? rightBar.vertices[0] : rightBar.vertices[2];
            armorPts[2] = rightBar.vertices[0].y < rightBar.vertices[2].y ? rightBar.vertices[0] : rightBar.vertices[2];
            armorPts[3] = leftBar.vertices[1].y < leftBar.vertices[3].y ? leftBar.vertices[1] : leftBar.vertices[3];

            armor.corners.resize(4);  // 
            std::copy(std::begin(armorPts), std::end(armorPts), std::begin(armor.corners));

            std::vector<cv::Point2f> pts_vec(armorPts, armorPts + 4);
            armor.boundingRect = cv::minAreaRect(pts_vec);
            
            armors.push_back(armor);

            // 调试：打印角点坐标
            std::cout << "装甲板角点坐标: " << armor.corners[0] << ", " << armor.corners[1] << ", " << armor.corners[2] << ", " << armor.corners[3] << std::endl;

        }
    }
    // 调试：打印装甲板数量
    std::cout << "检测到装甲板数量：" << armors.size() << std::endl;

    return armors;
}