#include "Congfig.hpp"
#include "Struct.hpp"
#include "PoseSlove.hpp"
#include "ExtendedKalman.hpp"
#include "Serial.hpp"
#include "DrawTrack.hpp"
#include <opencv2/opencv.hpp>
#include <iostream>
#include <cmath>
#include <algorithm>
#include "HikCamera.hpp"

int main()
{
    cv::setNumThreads(0);
    cv::setUseOptimized(false);
    
    //读取文件

    // 定义相机内参和畸变系数
    cv::Mat camera_matrix, dist_coeffs;

    cv::FileStorage fs("src/calib_result.yml", cv::FileStorage::READ);
    if (!fs.isOpened())
    {
        // 修复：cout << 正确写法
        std::cout << "[ERROR] 无法打开calib_result.yml" << std::endl;
        return -1;
    }
    fs["cameraMatrix"] >> camera_matrix;
    fs["distCoeffs"] >> dist_coeffs;
    fs.release();

    if (camera_matrix.empty() || camera_matrix.rows != 3 || camera_matrix.cols != 3) {
        std::cout << "PnPSolver::solve: 无效的相机内参，跳过位姿求解" << std::endl;
        return -1;
    }
    
    // 检测器
    ArmorsDetector armorsdetector(camera_matrix, dist_coeffs);

    // 卡尔曼追踪
    ExtendedKalman tracker;
    bool inited = false;

    cv::Point3f last_valid_position; 
    double last_valid_yaw;
    double last_valid_pitch;           
    cv::Mat last_valid_rvec;     
    
    // 打开串口
    Serial serial;
    if (!serial.open("/dev/ttyAMA0", B115200))
    {
        std::cerr << "无法打开串口" << std::endl;
        return -1;
    }

    // 视频.ver
    cv::VideoCapture cap("src/red1.mp4");
    if (!cap.isOpened())
    { 
        std::cerr << "视频打开失败" << std::endl;
        return -1;
    }
    
    // // 海康工业相机.ver
    // HikCamera cam;
    // if (!cam.init())
    // {
    //     return -1;
    // }

    cv::namedWindow("Armor Tracker", cv::WINDOW_NORMAL | cv::WINDOW_KEEPRATIO);
    cv::resizeWindow("Armor Tracker", 1280, 720); // 固定窗口大小
    
    cv::Mat frame;

    double timeStamp = 0.0;
    const double dt = 0.033;

    while (true)
    {
        // 【视频取流】
        if (!cap.read(frame))
        {
            break;
        }
        
        // // 海康工业取流
        // if (!cam.getFrame(frame))
        // {
        //     continue;
        // }
        
        if (frame.empty())
        {
            continue;
        }
        
        std::vector<Armors> armors = armorsdetector.detect(frame);

        if (!armors.empty())
        {
            const Armors& best = armors[0];

            cv::Point3f pos(
                best.tvec.at<double>(0),
                best.tvec.at<double>(1),
                best.tvec.at<double>(2)
            );

            double yaw = best.yaw;

            last_valid_position = pos;
            last_valid_yaw = yaw;
            last_valid_pitch = best.pitch;
            last_valid_rvec = best.rvec.clone(); 

            if (serial.is_open())
            {
                // 获取卡尔曼滤波器的预测值
                double pred_yaw_deg = tracker.getPredictedYawDeg();

                std::string data = std::to_string(pred_yaw_deg) + "," + std::to_string(last_valid_pitch) + "," + std::to_string(pos.x) + "," + std::to_string(pos.y) + "," + std::to_string(pos.z);
                
                if (!serial.writeString(data, true))
                {
                    std::cout << "[ERROR] 串口发送失败" << std::endl;
                }  
            }
            

            if (!inited)
            {
                tracker.init(pos, yaw, timeStamp);
                inited = true;
            }
            else
            {
                tracker.update(pos, yaw, timeStamp);
            }

            cv::Point3f est_pos = tracker.getEstimatedPosition();
            double pred_yaw_deg = tracker.getPredictedYawDeg();

            // 修正：传入检测到的装甲板，而不是空对象
            drawTrack(frame, best, est_pos, pred_yaw_deg, 
                      last_valid_rvec, camera_matrix, dist_coeffs);
        } 
        else
        {
            // 无检测到装甲板时，发送上一次的预测值
            if (serial.is_open())
            {
                std::string data = std::to_string(tracker.getPredictedYawDeg()) + "," + std::to_string(last_valid_pitch) + "," + std::to_string(last_valid_position.x) + "," + std::to_string(last_valid_position.y) + "," + std::to_string(last_valid_position.z);
                serial.writeString(data, true);
            }

            if (inited)
            {
                tracker.predict(timeStamp);
                cv::Point3f est_pos = tracker.getEstimatedPosition();
                double pred_yaw_deg = tracker.getPredictedYawDeg();

                drawTrack(frame, Armors(), est_pos, pred_yaw_deg, 
                          last_valid_rvec, camera_matrix, dist_coeffs);
            }
        }
        
        cv::imshow("Armor Tracker", frame);
        if (cv::waitKey(30) == 27)
        {
            break;
        }

        timeStamp += dt;
    }

    cap.release();
    // cam.release();
    cv::destroyAllWindows();
    serial.close();
    return 0;
}